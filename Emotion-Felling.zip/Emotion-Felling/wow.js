const discord = require("discord.js");
const { Random } = require("something-random-on-discord");
const random = new Random();

module.exports = {
  name: "ว้าว",
  category: "fun",
  description: "ต่อยกับคนที่คุณต้องการ",
  run: async (client, message, args) => {
    
    let target = message.mentions.members.first()
    
    let data = await random.getAnimeImgURL("happy");
    
    let embed = new discord.MessageEmbed()
		.setTitle("โอ้ว ว้าว!!")
		.setThumbnail("https://cdn.discordapp.com/attachments/886898948814569513/889830842476675122/giphy_1.gif")
    .setImage(data)
    .setColor("RANDOM")
    .setFooter(`${message.author.username} โอ้วสุดยอด ${target.user.username}`)
    .setTimestamp()
    
    message.channel.send(embed);
  }
};