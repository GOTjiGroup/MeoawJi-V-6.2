const discord = require("discord.js");
const { Random } = require("something-random-on-discord");
const random = new Random();

module.exports = {
  name: "ตื่นเต้น",
  category: "fun",
  description: "ต่อยกับคนที่คุณต้องการ",
  run: async (client, message, args) => {
    
    let target = message.mentions.members.first()
    
    let data = await random.getAnimeImgURL("happy");
    
    let embed = new discord.MessageEmbed()
		.setTitle("วะ วะ ว้าว เชี่ย!!")
		.setThumbnail("https://cdn.discordapp.com/attachments/886898948814569513/889833549954428948/excited-cute.gif")
    .setImage(data)
    .setColor("RANDOM")
    .setFooter(`${message.author.username} นายต้องไม่เชื่อแน่ ${target.user.username}`)
    .setTimestamp()
    
    message.channel.send(embed);
  }
};
