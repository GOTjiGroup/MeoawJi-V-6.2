const discord = require("discord.js");
const { Random } = require("something-random-on-discord");
const random = new Random();

module.exports = {
  name: "ต่อย",
  category: "fun",
  description: "ต่อยกับคนที่คุณต้องการ",
  run: async (client, message, args) => {
    
    let target = message.mentions.members.first()
    
    let data = await random.getAnimeImgURL("punch");
    
    let embed = new discord.MessageEmbed()
		.setTitle("Round 1")
		.setDescription(
					    `เป็นการชกกันระหว่าง`)
    .setImage(data)
    .setColor("RANDOM")
    .setFooter(`${message.author.username} Vs ${target.user.username}`)
    .setTimestamp()
    
    message.channel.send(embed);
  }
};
